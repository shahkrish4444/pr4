import React from 'react'

function SectionOne() {
    return (
        <section className='bg-transparent'>
            <div className='container'>
                <div className='row'>
                    <div className='col-lg-6'>
                        <h3>Voluptatem dignissimos provident quasi corporis voluptates sit assumenda.</h3>
                        <p>

                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore
                            magna aliqua.

                        </p>
                        <ul>
                            <li>Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                            <li>Ullamco laboris nisi ut aliquip ex ea commodo consequat.</li>
                            <li>Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate trideta storacalaperda mastiro dolore eu fugiat nulla pariatur.</li>
                        </ul>
                        <p>
                        Ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                        </p>
                    </div>
                    <div className='col-lg-6'>
                        <img src="https://bootstrapmade.com/demo/templates/Mentor/assets/img/about.jpg" alt="" className='img-fluid'/>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default SectionOne;