import React from "react";


const Card = () => {
  const cards = [
    {
      icon: "icons",
      image: "https://picsum.photos/id/100/200",
      description: "This is a user."
    },
    {
      icon: "fa-solid fa-envelope",
      image: "https://picsum.photos/id/101/200",
      description: "This is an envelope."
    },
    {
      icon: "fa-solid fa-phone",
      image: "https://picsum.photos/id/102/200",
      description: "This is a phone."
    },
    {
      icon: "fa-solid fa-camera",
      image: "https://picsum.photos/id/103/200",
      description: "This is a camera."
    }
  ];


  return (
    <>
    <div>
      {cards[0].description}
      {cards[0].icon}
      </div>
      </>
  )
}

export default Card
