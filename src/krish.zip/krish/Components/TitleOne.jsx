import React from 'react'

function TitleOne() {
  return (
    <section className='hero title bggimg'>
      <div className='container'>
        <h1>Learning Today,
          <br />
          Leading Tomorrow
        </h1>
        <h2>We are team of talented designers making websites with Bootstrap</h2>
        <a href="">Get Started</a>
      </div>
    </section>
  )
}

export default TitleOne